package edu.ycp.cs320.lab04.controller;

public class AddNumbersController {
	public Double add(Double first, Double second) {
		return first + second;
	}
}
