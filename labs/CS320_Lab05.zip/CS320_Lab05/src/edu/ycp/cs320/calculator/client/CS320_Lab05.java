package edu.ycp.cs320.calculator.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.user.client.ui.RootLayoutPanel;

import edu.ycp.cs320.calculator.shared.Operation;
import edu.ycp.cs320.calculator.shared.PerformOperation;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class CS320_Lab05 implements EntryPoint {
	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		Operation model = new Operation();
		PerformOperation controller = new PerformOperation();
		controller.setModel(model);
		
		OperationAndResultView view = new OperationAndResultView();
		view.setModel(model);
		view.setController(controller);
		
		RootLayoutPanel.get().add(view);
		RootLayoutPanel.get().setWidgetLeftWidth(view, 10.0, Unit.PX, 500.0, Unit.PX);
		RootLayoutPanel.get().setWidgetTopHeight(view, 10.0, Unit.PX, 400.0, Unit.PX);
	}
}
