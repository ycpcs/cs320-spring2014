package edu.ycp.cs320.calculator.client;

import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.LayoutPanel;

import edu.ycp.cs320.calculator.shared.IPublisher;
import edu.ycp.cs320.calculator.shared.ISubscriber;
import edu.ycp.cs320.calculator.shared.Operation;
import edu.ycp.cs320.calculator.shared.PerformOperation;
import edu.ycp.cs320.calculator.shared.Result;

public class OperationAndResultView extends Composite implements ISubscriber {
	private Result result;
	private Operation model;
	private PerformOperation controller;
	private ResultView resultView;
	
	public OperationAndResultView() {
		this.result = new Result();
		
		LayoutPanel panel = new LayoutPanel();
		initWidget(panel);

		this.resultView = new ResultView();
		resultView.setModel(result);
		panel.add(resultView);
		panel.setWidgetLeftWidth(resultView, 19.0, Unit.PX, 200.0, Unit.PX);
		panel.setWidgetTopHeight(resultView, 120.0, Unit.PX, 31.0, Unit.PX);
	}

	public void setModel(Operation model) {
		this.model = model;
		this.model.subscribe(Operation.Events.VALUE_OR_OPERATION_TYPE_CHANGED, this);
	}

	public void setController(PerformOperation controller) {
		this.controller = controller;
	}
	
	@Override
	public void eventOccurred(Object key, IPublisher publisher, Object hint) {
//		if (key == Operation.Events.VALUE_OR_OPERATION_TYPE_CHANGED) {
//			firstNumberTextBox.setText(String.valueOf(model.getFirst()));
//			secondNumberTextBox.setText(String.valueOf(model.getSecond()));
//		}
	}
}
