package edu.ycp.cs320.calculator.shared;

public enum OperationType {
	ADD,
	SUBTRACT,
	MULTIPLY,
	DIVIDE,
}
