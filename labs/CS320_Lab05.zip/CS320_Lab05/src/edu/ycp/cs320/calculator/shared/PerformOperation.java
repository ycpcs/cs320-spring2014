package edu.ycp.cs320.calculator.shared;

public class PerformOperation {
	private Operation model;
	
	public void setModel(Operation model) {
		this.model = model;
	}
	
	public void setOperationType(OperationType type) {
		model.setType(type);
	}
	
	public void setLeftValue(double value) {
		model.setFirst(value);
	}
	
	public void setRightValue(double value) {
		model.setSecond(value);
	}
	
	public void perform(Result result) {
		double resultValue;
		switch (model.getType()) {
		case ADD:
			resultValue = model.getFirst() + model.getSecond();
			break;
		case DIVIDE:
			resultValue = model.getFirst() / model.getSecond();
			break;
		case MULTIPLY:
			resultValue = model.getFirst() * model.getSecond();
			break;
		case SUBTRACT:
			resultValue = model.getFirst() - model.getSecond();
			break;
		default:
			throw new UnsupportedOperationException("Unknown operation type: " + model.getType());
		}
		
		result.setValue(resultValue);
	}
}
