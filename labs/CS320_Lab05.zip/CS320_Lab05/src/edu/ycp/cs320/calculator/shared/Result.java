package edu.ycp.cs320.calculator.shared;

public class Result extends Publisher {
	public enum Events {
		VALUE_CHANGED,
	}
	
	private double value;
	
	public Result() {
		value = 0.0;
	}
	
	public void setValue(double value) {
		this.value = value;
		notifySubscribers(Events.VALUE_CHANGED, value);
	}
	
	public double getValue() {
		return value;
	}
}
