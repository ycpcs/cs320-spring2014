package edu.ycp.cs320.calculator.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.user.client.ui.RootLayoutPanel;

import edu.ycp.cs320.calculator.shared.Operation;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class CS320_Lab09 implements EntryPoint {
	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		Operation model = new Operation();
		
		OperationAndResultView view = new OperationAndResultView();
		view.setModel(model);
		
		RootLayoutPanel.get().add(view);
		RootLayoutPanel.get().setWidgetLeftWidth(view, 10.0, Unit.PX, 500.0, Unit.PX);
		RootLayoutPanel.get().setWidgetTopHeight(view, 10.0, Unit.PX, 400.0, Unit.PX);
	}
}
