package edu.ycp.cs320.calculator.client;

import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.InlineLabel;
import com.google.gwt.user.client.ui.LayoutPanel;
import com.google.gwt.user.client.ui.TextBox;

import edu.ycp.cs320.calculator.shared.IPublisher;
import edu.ycp.cs320.calculator.shared.ISubscriber;
import edu.ycp.cs320.calculator.shared.Operation;
import edu.ycp.cs320.calculator.shared.OperationType;
import edu.ycp.cs320.calculator.shared.OperationResult;

import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.ClickEvent;

public class OperationAndResultView extends Composite implements ISubscriber {
	private OperationResult operationResult;
	private Operation model;
	private ResultView resultView;
	private TextBox value1TextBox;
	private TextBox value2TextBox;
	
	public OperationAndResultView() {
		this.operationResult = new OperationResult();
		
		LayoutPanel panel = new LayoutPanel();
		initWidget(panel);

		this.resultView = new ResultView();
		resultView.setModel(operationResult);
		panel.add(resultView);
		panel.setWidgetLeftWidth(resultView, 19.0, Unit.PX, 200.0, Unit.PX);
		panel.setWidgetTopHeight(resultView, 120.0, Unit.PX, 31.0, Unit.PX);
		
		InlineLabel value1Label = new InlineLabel("Value 1:");
		panel.add(value1Label);
		panel.setWidgetLeftWidth(value1Label, 19.0, Unit.PX, 104.0, Unit.PX);
		panel.setWidgetTopHeight(value1Label, 37.0, Unit.PX, 15.0, Unit.PX);
		
		InlineLabel value2Label = new InlineLabel("Value 2:");
		panel.add(value2Label);
		panel.setWidgetLeftWidth(value2Label, 19.0, Unit.PX, 104.0, Unit.PX);
		panel.setWidgetTopHeight(value2Label, 78.0, Unit.PX, 15.0, Unit.PX);
		
		value1TextBox = new TextBox();
		panel.add(value1TextBox);
		panel.setWidgetLeftWidth(value1TextBox, 165.0, Unit.PX, 179.0, Unit.PX);
		panel.setWidgetTopHeight(value1TextBox, 21.0, Unit.PX, 31.0, Unit.PX);
		
		value2TextBox = new TextBox();
		panel.add(value2TextBox);
		panel.setWidgetLeftWidth(value2TextBox, 165.0, Unit.PX, 179.0, Unit.PX);
		panel.setWidgetTopHeight(value2TextBox, 62.0, Unit.PX, 31.0, Unit.PX);
		
		Button addButton = new Button("Add");
		addButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				handleAdd();
			}
		});
		panel.add(addButton);
		panel.setWidgetLeftWidth(addButton, 19.0, Unit.PX, 91.0, Unit.PX);
		panel.setWidgetTopHeight(addButton, 198.0, Unit.PX, 27.0, Unit.PX);
		
		Button subtractButton = new Button("Subtract");
		subtractButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				handleSubtract();
			}
		});
		panel.add(subtractButton);
		panel.setWidgetLeftWidth(subtractButton, 128.0, Unit.PX, 91.0, Unit.PX);
		panel.setWidgetTopHeight(subtractButton, 198.0, Unit.PX, 27.0, Unit.PX);
		
		Button multiplyButton = new Button("Multiply");
		multiplyButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				handleMultiply();
			}
		});
		panel.add(multiplyButton);
		panel.setWidgetLeftWidth(multiplyButton, 238.0, Unit.PX, 91.0, Unit.PX);
		panel.setWidgetTopHeight(multiplyButton, 198.0, Unit.PX, 27.0, Unit.PX);
		
		Button divisionButton = new Button("Divide");
		divisionButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				handleDivide();
			}
		});
		panel.add(divisionButton);
		panel.setWidgetLeftWidth(divisionButton, 348.0, Unit.PX, 91.0, Unit.PX);
		panel.setWidgetTopHeight(divisionButton, 198.0, Unit.PX, 27.0, Unit.PX);
	}
	
	private void updateModel(OperationType operationType) {
		model.setFirst(Double.parseDouble(value1TextBox.getText()));
		model.setSecond(Double.parseDouble(value2TextBox.getText()));
		model.setType(operationType);
	}

	
	
	protected void handleAdd() {
		updateModel(OperationType.ADD);
		
		// TODO: use RPC to perform operation, update result
	}

	protected void handleSubtract() {
		updateModel(OperationType.SUBTRACT);
		
		// TODO: use RPC to perform operation, update result
	}

	protected void handleMultiply() {
		updateModel(OperationType.MULTIPLY);
		
		// TODO: use RPC to perform operation, update result
	}

	protected void handleDivide() {
		updateModel(OperationType.DIVIDE);
		
		// TODO: use RPC to perform operation, update result
	}

	public void setModel(Operation model) {
		this.model = model;
		this.model.subscribe(Operation.Events.VALUE_OR_OPERATION_TYPE_CHANGED, this);
	}
	
	@Override
	public void eventOccurred(Object key, IPublisher publisher, Object hint) {
//		if (key == Operation.Events.VALUE_OR_OPERATION_TYPE_CHANGED) {
//			firstNumberTextBox.setText(String.valueOf(model.getFirst()));
//			secondNumberTextBox.setText(String.valueOf(model.getSecond()));
//		}
	}
}
