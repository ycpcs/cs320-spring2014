package edu.ycp.cs320.calculator.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

import edu.ycp.cs320.calculator.shared.Operation;
import edu.ycp.cs320.calculator.shared.OperationResult;

@RemoteServiceRelativePath("performOperation")
public interface PerformOperationService extends RemoteService {
	// TODO: add performOperation method
}
