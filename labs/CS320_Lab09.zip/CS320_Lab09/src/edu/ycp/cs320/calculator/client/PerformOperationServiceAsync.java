package edu.ycp.cs320.calculator.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

import edu.ycp.cs320.calculator.shared.Operation;
import edu.ycp.cs320.calculator.shared.OperationResult;

public interface PerformOperationServiceAsync {
}
