package edu.ycp.cs320.calculator.server;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import edu.ycp.cs320.calculator.client.PerformOperationService;
import edu.ycp.cs320.calculator.shared.Operation;
import edu.ycp.cs320.calculator.shared.OperationResult;

public class PerformOperationServiceImpl extends RemoteServiceServlet implements
		PerformOperationService {
}
