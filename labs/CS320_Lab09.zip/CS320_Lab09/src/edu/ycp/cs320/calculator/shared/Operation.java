package edu.ycp.cs320.calculator.shared;

import java.io.Serializable;

public class Operation extends Publisher implements Serializable {
	public enum Events {
		VALUE_OR_OPERATION_TYPE_CHANGED,
	}
	
	private double first, second;
	private OperationType type;
	
	public Operation() {
		
	}
	
	public void setFirst(double first) {
		this.first = first;
		notifySubscribers(Events.VALUE_OR_OPERATION_TYPE_CHANGED, null);
	}
	
	public double getFirst() {
		return first;
	}
	
	public void setSecond(double second) {
		this.second = second;
		notifySubscribers(Events.VALUE_OR_OPERATION_TYPE_CHANGED, null);
	}
	
	public double getSecond() {
		return second;
	}
	
	public void setType(OperationType type) {
		this.type = type;
		notifySubscribers(Events.VALUE_OR_OPERATION_TYPE_CHANGED, null);
	}
	
	public OperationType getType() {
		return type;
	}
}
