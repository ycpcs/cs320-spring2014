package edu.ycp.cs320.calculator.shared;

import java.io.Serializable;

public class OperationResult extends Publisher implements Serializable {
	public enum Events {
		VALUE_CHANGED,
	}
	
	private double value;
	
	public OperationResult() {
		value = 0.0;
	}
	
	public void setValue(double value) {
		this.value = value;
		notifySubscribers(Events.VALUE_CHANGED, value);
	}
	
	public double getValue() {
		return value;
	}
}
